package com.stackroute.keepnote.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.stackroute.keepnote.exception.NoteNotFoundException;
import com.stackroute.keepnote.model.Note;

/*
 * This class is implementing the UserDAO interface. This class has to be annotated with 
 * @Repository annotation.
 * @Repository - is an annotation that marks the specific class as a Data Access Object, 
 * thus clarifying it's role.
 * @Transactional - The transactional annotation itself defines the scope of a single database 
 * 					transaction. The database transaction happens inside the scope of a persistence 
 * 					context.  
 * */
@Repository
@Transactional
public class NoteDAOImpl implements NoteDAO {

	/*
	 * Autowiring should be implemented for the SessionFactory.(Use
	 * constructor-based autowiring.
	 */


	@Autowired
	SessionFactory sessionFactory;
	

	public NoteDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	/*
	 * Create a new note
	 */
	
	public boolean createNote(Note note) {
		boolean saveFlag = false;
		try {
			sessionFactory.getCurrentSession().save(note);
			saveFlag= true;
		}
		catch (Exception e) {
		}
		return saveFlag;

	}

	/*
	 * Remove an existing note
	 */
	
	public boolean deleteNote(int noteId) {
		try {
				sessionFactory.getCurrentSession().createQuery("delete from Note where note_id ="+noteId).executeUpdate();
				return true;
			} catch (Exception e) {
				e.printStackTrace();
			}
			return false;
	}

	/*
	 * Retrieve details of all notes by userId
	 */
	
	public List<Note> getAllNotesByUserId(String userId) {
		List<Note> noteList =  sessionFactory.getCurrentSession().createQuery("from Note").list();
		return noteList;
	}

	/*
	 * Retrieve details of a specific note
	 */
	
	public Note getNoteById(int noteId) throws NoteNotFoundException {
		Note note = (Note) sessionFactory.getCurrentSession().load(Note.class, noteId);
		return note;

	}

	/*
	 * Update an existing note
	 */

	public boolean UpdateNote(Note note) {
		try {
			sessionFactory.getCurrentSession().saveOrUpdate(note);
			return true;
		} catch (Exception e) {
		}
		return false;

	}

}
